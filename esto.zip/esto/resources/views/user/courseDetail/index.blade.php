@extends('user.layout.index')
@section('content')
    @include('user.courseDetail.content');
@endsection
