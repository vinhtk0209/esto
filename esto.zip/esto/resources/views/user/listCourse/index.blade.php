@extends('user.layout.index')
@section('content')
    @include('user.listCourse.content')
@endsection
