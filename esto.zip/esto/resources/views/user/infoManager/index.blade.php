@extends('user.layout.index')
@section('content')
    @include('user.infoManager.content');
@endsection
