<section class="info-container">
    <section class="header-info-manager">
        <div class="container">
            <h1>Khóa học của tôi</h1>
        </div>
    </section>
    <div class="userProfileTabs">
        <div class="container">
            {{-- NAME TAB --}}
            <ul class="nav nav-pills tab-info " id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Khóa học</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Quản lý đơn hàng</button>
                </li>
              </ul>
              {{-- COTENT TAB --}}
              <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque omnis animi inventore at tenetur explicabo impedit, earum ea eligendi neque?</div>
                <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptatem tempora porro atque quia. Itaque laborum, illum autem voluptates repudiandae delectus quia excepturi tempora laboriosam odio facere repellat ut nostrum quo eligendi iste quidem ducimus impedit alias minima incidunt totam ab? Quidem, enim consequatur ex mollitia corrupti aut iusto deserunt corporis.</div>
              </div>

        </div>
    </div>

</section>
