@extends('user.layout.index')
@section('content')
    @include('user.homepage.category');
    @include('user.homepage.content');
@endsection
