<?php $__env->startSection('content'); ?>
<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="admin/taikhoan/"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="admin/taikhoan/">Quản Lý Tài Khoản</a></li>
                        </ol>
                    </nav>
                </div>
                <div class="col-lg-6 col-5 text-right">
                    <a href="admin/taikhoan/them" class="btn btn-sm btn-neutral">Thêm</a>
                </div>
            </div>
            <div>
            <div class="col-lg-6 col-5 text-right">
                    
               
                <div class="col-lg-6 col-5 text-right">
                    <a href="admin/taikhoan/search=1" class="btn btn-sm btn-neutral">Học viên</a>
                    <a href="admin/taikhoan/search=2" class="btn btn-sm btn-neutral">Giảng Viên</a>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <!-- Card header -->
                <div class="card-header border-0 text-blue">
                    <h3 class="mb-0">Tài khoản</h3>
                </div>
                <?php if(session('thongbao')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('thongbao')); ?>

                </div>
                <?php endif; ?>
                <!-- Light table -->
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col" class="sort" data-sort="hoten">Họ và tên</th>
                                <th scope="col" class="sort" data-sort="ngaysinh">Ngày sinh</th>
                                <th scope="col" class="sort" data-sort="gioitinh">Giới tính</th>
                                <th scope="col" class="sort" data-sort="sodienthoai">Số điện thoại</th>
                                <th scope="col" class="sort" data-sort="email">Email</th>
                                <th scope="col" class="sort" data-sort="trangthai">Trạng thái</th>
                                <th scope="col" class="sort" data-sort="options"></th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__currentLoopData = $taikhoan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="budget">
                                    <?php echo e($tk->HOTEN); ?>

                                </td>
                                <td class="budget">
                                    <?php echo e($tk->NGAYSINH); ?>

                                </td>
                                <td class="budget">
                                    <?php echo e($tk->GIOITINH==1?'Nam':'Nữ'); ?>

                                </td>
                                <td class="budget">
                                    <?php echo e($tk->SODIENTHOAI); ?>

                                </td>
                                <td class="budget">
                                    <?php echo e($tk->EMAIL); ?>

                                </td>
                                <td class="budget">
                                    <?php echo e($tk->TRANGTHAI==1?'Hoạt động':'Vô hiệu hóa'); ?>

                                </td>
                                <td class="center">
                                    <a href="admin/taikhoan/sua/<?php echo e($tk->ID); ?>" class="edit text-yellow" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                    <a href="admin/taikhoan/xoa/<?php echo e($tk->ID); ?>" class="delete text-red" title="Delete" data-toggle="tooltip" onclick="return confirm('Bạn có muốn xóa tài khoản này?')"><i class="material-icons">&#xE872;</i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- Card footer -->
                <div class="card-footer py-4">
                    <ul class="pagination justify-content-end mb-0">
                        <li class="page-item">
                            <a class="page-link" href="admin/taikhoan?page=1">
                                <i class="fas fa-angle-double-left"></i>
                            </a>
                        </li>
                        <?php if($taikhoan->currentPage() == 1): ?>
                        <li class="page-item disabled">
                            <?php else: ?>
                        <li class="page-item">
                            <?php endif; ?>
                            <a class="page-link" href="<?php echo e($taikhoan->previousPageUrl()); ?>">
                                <i class="fas fa-angle-left"></i>
                            </a>
                        </li>
                        <?php if($taikhoan->currentPage() == $taikhoan->lastPage()): ?>
                        <li class="page-item disabled">
                            <?php else: ?>
                        <li class="page-item">
                            <?php endif; ?>
                            <a class="page-link" href="<?php echo e($taikhoan->nextPageUrl()); ?>">
                                <i class="fas fa-angle-right"></i>
                            </a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="admin/taikhoan?page=<?php echo e($taikhoan->lastPage()); ?>">
                                <i class="fas fa-angle-double-right"></i>
                            </a>
                        </li>
                    </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/esto/resources/views/admin/taikhoan/index.blade.php ENDPATH**/ ?>