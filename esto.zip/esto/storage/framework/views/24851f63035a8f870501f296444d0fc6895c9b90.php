<section class="category ">
    <div class="container">
        <div class="d-flex flex-wrap flex-space">
            <ul class="list-category">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-item">
                    <a href="">
                        <?php echo e($value->TENDM); ?>

                    </a>
                    

                        
                    
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                
            </ul>
            <div class="swiper slide-category">
                <div class="swiper-wrapper">
                    <div class="swiper-slide"><img src="<?php echo e(asset('user/assets/img/slide-3.png')); ?>">
                    </div>
                    <div class="swiper-slide"><img src="<?php echo e(asset('user/assets/img/slide-4.png')); ?>">
                    </div>
                    <div class="swiper-slide"><img src="<?php echo e(asset('user/assets/img/slide-5.png')); ?>"></div>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/esto/resources/views/user/homepage/category.blade.php ENDPATH**/ ?>