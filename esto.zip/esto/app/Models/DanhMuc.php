<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DanhMuc extends Model
{
    protected $table = "danhmuc";
    protected $primaryKey = 'MADM';
    protected $guarded = [];
    
    public function childCategory()
    {
        return $this->hasMany(DanhMuc::class, 'MADMC');
    }
}
